<?php get_header() ?>

<!-- ADVERTISERS SERVICE CARD -->
<section id="advertisers" class="advertisers-service-sec pt-5 pb-5">
  <div class="container">
    <div class="row">
      <!-- title articles -->
      <div class="section-header">
        <h1 class="fw-bold fs-1">
            Mes
          <span class="b-class-secondary">articles </span> de mon blog
        </h1>
        <p class="sec-icon"><i class="fa-solid fa-gear"></i></p>
      </div>
    </div>
    <!-- cards -->
    <div class="row">
    <?php if (have_posts()): while (have_posts()): the_post(); ?>
      <div class="col-md-4 mt-4">
        <div class="service-card">
          <div class="icon-wrapper">
            <i class="fa-solid fa-chart-line"></i>
          </div>
          <h3><?php the_title(); ?></h3>
          <p>
            <?php the_content() ?>
          </p>
          <?= get_search_form() ?>
        </div>
      </div>
      <?php endwhile; else: ?>
        <h1 class="display-1">Aucun article de disponible</h1>
        <?php endif; ?>
    </div>
  </div>
</section>
<!-- ADVERTISERS SERVICE CARD ENDED -->

<?php get_footer() ?>